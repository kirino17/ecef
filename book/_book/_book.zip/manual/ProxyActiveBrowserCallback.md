# 水星获取活动浏览器回调
###### 用于扩展程序事件扩展程序取活动浏览器。向扩展程序返回当前应用程序中的活动浏览器对象。

| `Quick Links` |
|:----|
|<a href="#SetBrowser"  style="color:rgb(128,0,0)">置活动浏览器</a> , |

---------------------
 `功能函数` <br/>

| <span style="color:rgb(128,0,0)" id="SetBrowser">置活动浏览器</span> |
|:----|
| <span style="color:rgb(0,128,0)">设置活动浏览器。<span> |
| <span style="color: rgb(117, 110, 200)">@param</span> <a href="ProxyBrowser.md" style ="color: blue">水星浏览器</a> 浏览器 <span style="color: rgb(0, 128, 0)">浏览器</span> | 
| <span style="color: rgb(117, 110, 200)">@return </span> <span style ="color: blue">无返回值</span> |


----------------------

<link rel="stylesheet" href="../gitalk.min.css">
<script src="../gitalk.min.js"></script>
<div id="gitalk-container"></div>
<script>
    var gitalk = new Gitalk({
        clientID: 'd17d49be2e680b77a84d',
        clientSecret:'9364cb456dda6401cb71d65092489e75c9f11872',
        repo: 'ecef_comment',
        owner: 'kirino17',
        admin: ['kirino17'],
        id: location.pathname
    });
    gitalk.render('gitalk-container');
</script>
